;(function(window) {
	// 创建 Vue 实例
	const vm = new Vue({
		el: '#app',
		data: {
			// 列表数据
			list: [
				{ id: 1, name: '吃饭', done: true },
				{ id: 2, name: '睡觉', done: false },
				{ id: 3, name: '打豆豆', done: true }
			]
		}
	})
})(window)
