;(function(window) {
	'use strict'

	// Your starting point. Enjoy the ride!

})(window)
