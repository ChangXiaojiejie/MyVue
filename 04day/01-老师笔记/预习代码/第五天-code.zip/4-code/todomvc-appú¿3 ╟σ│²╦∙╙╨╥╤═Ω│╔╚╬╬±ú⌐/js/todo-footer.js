Vue.component('todo-footer', {
	template: `
		<footer class="footer">
			<span class="todo-count"><strong>0</strong> item left</span>
			<ul class="filters">
				<li>
					<a class="selected" href="#/">All</a>
				</li>
				<li>
					<a href="#/active">Active</a>
				</li>
				<li>
					<a href="#/completed">Completed</a>
				</li>
			</ul>
			<button class="clear-completed" @click="clearCompleted">Clear completed</button>
		</footer>
	`,

	methods: {
		// 清除所有已完成任务
		clearCompleted() {
			// console.log('clearCompleted')

			// 希望父组件提供一个清除已完成任务的事件
			// 注意：本次触发事件不需要传递参数，因为 已完成的任务 是固定的状态，就是 item.done 为false
			this.$emit('clear-completed')
		}
	}
})
