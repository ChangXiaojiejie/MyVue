/*
	Vue实例职责：
		1 负责提供list数据，给各个子组件使用

*/

;(function(window) {
	'use strict'

	// 创建Vue实例
	const vm = new Vue({
		el: '#app',
		data: {
			list: [
				{ id: 1, name: '吃饭', done: false },
				{ id: 2, name: '上课', done: true },
				{ id: 3, name: '学Vue', done: false }
			]
		},

		methods: {
			// 父组件中要完成添加任务操作
			parentAddTodo(name) {
				// console.log('父组件中接受到任务名为：', name)
				const id =
					this.list.length === 0 ? 1 : this.list[this.list.length - 1].id + 1
				this.list.push({
					id,
					name,
					done: false
				})
			},

			// 删除任务
			parentDelTodo(id) {
				const index = this.list.findIndex(item => item.id === id)
				this.list.splice(index, 1)
			},

			// 清除所有已完成任务
			parentClearCompleted() {
				this.list = this.list.filter(item => !item.done)
			}
		}
	})

	// 暴露
	window.vm = vm
})(window)
