/*
	Vue实例职责：
		1 负责提供list数据，给各个子组件使用

*/

;(function(window) {
	'use strict'

	// 创建Vue实例
	const vm = new Vue({
		el: '#app',
		data: {
			list: [
				{ id: 1, name: '吃饭', done: false },
				{ id: 2, name: '上课', done: true },
				{ id: 3, name: '学Vue', done: false }
			]
		}
	})

	// 暴露
	window.vm = vm
})(window)
