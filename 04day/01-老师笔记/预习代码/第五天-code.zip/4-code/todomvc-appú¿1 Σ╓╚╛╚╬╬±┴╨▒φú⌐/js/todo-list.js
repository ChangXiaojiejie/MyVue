// 列表组件
Vue.component('todo-list', {
	template: `
		<section class="main">
			<input id="toggle-all" class="toggle-all" type="checkbox">
			<label for="toggle-all">Mark all as complete</label>
			<ul class="todo-list">
				<li :class="{ completed: item.done }" v-for="item in todos" :key="item.id">
					<div class="view">
						<input class="toggle" type="checkbox" v-model="item.done">
						<label>{{ item.name }}</label>
						<button class="destroy"></button>
					</div>
					<input class="edit" v-model="item.name">
				</li>
			</ul>
		</section>
	`,

	// 通过props接收父组件中传递过来的数据
	props: ['todos']
})
