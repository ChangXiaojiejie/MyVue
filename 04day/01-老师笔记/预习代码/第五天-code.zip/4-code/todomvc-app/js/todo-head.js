/*
	职责：完成任务添加功能
		1 获取到文本框的值

	数据放在哪个组件？？？ 如果数据只在当前组件中用到了，那么，数据就由当前组件提供
	比如：要添加的任务名称（ todoName ）
*/

// 头部组件
Vue.component('todo-header', {
	template: `
		<header class="header">
			<h1>todos</h1>
			<input class="new-todo" placeholder="What needs to be done?" v-model="todoName" @keyup.enter="addTodo">
		</header>
	`,

	data() {
		return {
			// 添加任务名称
			todoName: ''
		}
	},

	methods: {
		// 添加任务
		addTodo() {
			// 非空校验
			if (this.todoName.trim() === '') {
				return
			}

			// 添加
			// 子组件希望父组件将来给我传递一个名字叫 add-todo 事件名称
			this.$emit('add-todo', this.todoName)

			// 清空文本框
			this.todoName = ''
		}
	}
})
