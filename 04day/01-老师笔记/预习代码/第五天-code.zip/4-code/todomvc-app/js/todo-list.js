/*
	职责：
		1 展示list列表数据
		2 删除任务
		3 编辑任务
			3.1 展示编辑状态
			3.2 修改数据

*/

// 列表组件
Vue.component('todo-list', {
	template: `
		<section class="main">
			<input id="toggle-all" class="toggle-all" type="checkbox">
			<label for="toggle-all">Mark all as complete</label>
			<ul class="todo-list">
				<li :class="{ completed: item.done, editing: item.id === editId }" v-for="item in todos" :key="item.id">
					<div class="view">
						<input class="toggle" type="checkbox" v-model="item.done">
						<label @dblclick="showEdit(item.id)">{{ item.name }}</label>
						<button class="destroy" @click="delTodo(item.id)"></button>
					</div>
					<input class="edit" v-model="item.name" @keyup.enter="update">
				</li>
			</ul>
		</section>
	`,

	// 通过props接收父组件中传递过来的数据
	props: ['todos'],

	// 提供数据
	data() {
		return {
			editId: -1
		}
	},

	methods: {
		// 删除任务
		delTodo(id) {
			// console.log('要删除的id为：', id)

			// 调用父组件中提供的方法
			this.$emit('del-todo', id)
		},

		// 展示编辑状态
		showEdit(id) {
			this.editId = id
		},

		// 完成更新
		update() {
			this.editId = -1
		}
	}
})
